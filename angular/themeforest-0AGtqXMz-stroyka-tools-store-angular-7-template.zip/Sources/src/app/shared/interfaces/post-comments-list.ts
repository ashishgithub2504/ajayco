import { PostComment } from './post-comment';

export interface PostCommentsList {
    count: number;
    items: PostComment[];
}
