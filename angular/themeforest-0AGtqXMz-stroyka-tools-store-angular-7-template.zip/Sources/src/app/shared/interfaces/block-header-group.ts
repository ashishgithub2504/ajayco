export interface BlockHeaderGroup {
    name: string;
    current: boolean;
}
