export interface Brand {
    id: number;
    name: string;
    slug: string;
    image: string;
}
