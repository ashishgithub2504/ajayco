export interface BrandDef {
    name: string;
    slug: string;
    image: string;
}
